@echo off
echo ==========================================
echo   Instalando librerias para la Mano
echo ==========================================
pip install opencv-python mediapipe pyserial
echo.
echo ==========================================
echo   ¡Todo listo! Ya puedes cerrar esta ventana.
echo ==========================================
pause